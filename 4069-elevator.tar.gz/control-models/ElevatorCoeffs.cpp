#include "subsystems/ElevatorCoeffs.hpp"

#include <Eigen/Core>

frc::StateSpacePlantCoeffs<2, 1, 2> MakeElevatorPlantCoeffs() {
  Eigen::Matrix<double, 2, 2> A;
  A(0, 0) = 1.0;
  A(0, 1) = 0.0038123917094548044;
  A(1, 0) = 0.0;
  A(1, 1) = 0.09251846318419062;
  Eigen::Matrix<double, 2, 1> B;
  B(0, 0) = 0.000587130443210727;
  B(1, 0) = 0.08610920599650167;
  Eigen::Matrix<double, 2, 2> C;
  C(0, 0) = 1.0;
  C(0, 1) = 0.0;
  C(1, 0) = 0.0;
  C(1, 1) = 1.0;
  Eigen::Matrix<double, 2, 1> D;
  D(0, 0) = 0.0;
  D(1, 0) = 0.0;
  return frc::StateSpacePlantCoeffs<2, 1, 2>(A, B, C, D);
}

frc::StateSpaceControllerCoeffs<2, 1, 2> MakeElevatorControllerCoeffs() {
  Eigen::Matrix<double, 1, 2> K;
  K(0, 0) = 197.74500975121012;
  K(0, 1) = 1.5868649265235129;
  Eigen::Matrix<double, 1, 2> Kff;
  Kff(0, 0) = 27.107309014237973;
  Kff(0, 1) = 9.9389704745734;
  Eigen::Matrix<double, 1, 1> Umin;
  Umin(0, 0) = -12.0;
  Eigen::Matrix<double, 1, 1> Umax;
  Umax(0, 0) = 12.0;
  return frc::StateSpaceControllerCoeffs<2, 1, 2>(K, Kff, Umin, Umax);
}

frc::StateSpaceObserverCoeffs<2, 1, 2> MakeElevatorObserverCoeffs() {
  Eigen::Matrix<double, 2, 2> K;
  K(0, 0) = 0.999975001250821;
  K(0, 1) = 8.643017503810648e-11;
  K(1, 0) = 8.643017503781394e-09;
  K(1, 1) = 0.990099840624703;
  return frc::StateSpaceObserverCoeffs<2, 1, 2>(K);
}

frc::StateSpaceLoop<2, 1, 2> MakeElevatorLoop() {
  return frc::StateSpaceLoop<2, 1, 2>(MakeElevatorPlantCoeffs(),
                                      MakeElevatorControllerCoeffs(),
                                      MakeElevatorObserverCoeffs());
}
